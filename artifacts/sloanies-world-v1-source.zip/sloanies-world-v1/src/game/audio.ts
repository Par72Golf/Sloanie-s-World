let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let muted = false;

function ensure() {
  if (ctx) return ctx;
  const AC =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext })
      .webkitAudioContext;
  ctx = new AC({ latencyHint: "interactive" });
  master = ctx.createGain();
  master.gain.value = muted ? 0 : 0.22;
  master.connect(ctx.destination);
  return ctx;
}

export function unlockAudio() {
  const c = ensure();
  if (c.state === "suspended") void c.resume();
}

export function setMuted(v: boolean) {
  muted = v;
  if (master) {
    master.gain.setTargetAtTime(v ? 0 : 0.22, ensure().currentTime, 0.03);
  }
}

function tone(
  freq: number,
  dur: number,
  type: OscillatorType,
  gain = 0.18,
  at = 0,
  slide?: number,
) {
  const c = ensure();
  if (c.state === "suspended") return;
  const t = c.currentTime + at;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  if (slide) osc.frequency.exponentialRampToValueAtTime(slide, t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + 0.018);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.connect(g);
  g.connect(master!);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}

export const sfx = {
  jump: () => tone(420, 0.12, "square", 0.08, 0, 280),
  collect: () => {
    tone(523, 0.12, "triangle", 0.16);
    tone(659, 0.14, "triangle", 0.14, 0.08);
    tone(784, 0.22, "triangle", 0.14, 0.16);
  },
  correct: () => {
    tone(523, 0.1, "sine", 0.14);
    tone(659, 0.12, "sine", 0.14, 0.08);
    tone(784, 0.18, "sine", 0.16, 0.16);
  },
  wrong: () => tone(220, 0.18, "square", 0.08, 0, 160),
  flee: () => {
    tone(392, 0.12, "triangle", 0.12, 0, 220);
    tone(247, 0.18, "triangle", 0.12, 0.1, 140);
    tone(164, 0.28, "sine", 0.1, 0.2, 90);
  },
  hint: () => {
    tone(880, 0.08, "sine", 0.1);
    tone(1174, 0.12, "sine", 0.08, 0.08);
  },
  win: () => {
    [523, 659, 784, 1046].forEach((f, i) =>
      tone(f, 0.22, "triangle", 0.14, i * 0.12),
    );
  },
  step: () => tone(140 + Math.random() * 30, 0.05, "sine", 0.03),
  click: () => tone(640, 0.05, "square", 0.05),
};
