import type { QuizQ } from "./types";

const used = new Set<string>();

export function resetQuizBank() {
  used.clear();
}

function shuffle<T>(arr: T[]) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j]!, a[i]!];
  }
  return a;
}

function uniqueChoices(answer: number, extras: number[]) {
  const set = new Set<number>([answer]);
  for (const n of extras) {
    if (n !== answer && n >= 0 && n <= 20 && !set.has(n)) set.add(n);
    if (set.size >= 3) break;
  }
  let guard = 0;
  while (set.size < 3 && guard++ < 24) {
    const n = answer + (Math.random() < 0.5 ? 1 : -1) * (1 + Math.floor(Math.random() * 3));
    if (n >= 0 && n <= 20 && n !== answer) set.add(n);
  }
  return shuffle(Array.from(set)).slice(0, 3);
}

function addWithin(minA: number, maxA: number, maxSum: number, dots: boolean): QuizQ {
  const a = minA + Math.floor(Math.random() * (maxA - minA + 1));
  const maxB = Math.min(9, maxSum - a);
  const b = 1 + Math.floor(Math.random() * Math.max(1, maxB));
  const answer = a + b;
  return {
    prompt: `${a} + ${b}`,
    answer,
    choices: uniqueChoices(answer, [answer + 1, answer - 1, a, b, Math.abs(a - b)]),
    visual: dots ? [a, b] : undefined,
  };
}

function subWithin(minA: number, maxA: number): QuizQ {
  const a = minA + Math.floor(Math.random() * (maxA - minA + 1));
  const b = 1 + Math.floor(Math.random() * Math.min(9, a - 1));
  const answer = a - b;
  return {
    prompt: `${a} − ${b}`,
    answer,
    choices: uniqueChoices(answer, [answer + 1, answer - 1, a + b, b, a]),
  };
}

function generate(found: number): QuizQ {
  if (found < 4) return addWithin(1, 8, 10, true);
  if (found < 8) {
    return Math.random() < 0.65 ? addWithin(4, 9, 18, false) : subWithin(6, 12);
  }
  return Math.random() < 0.55 ? addWithin(6, 11, 20, false) : subWithin(8, 18);
}

export function makeQuestion(_levelIndex: number, found: number): QuizQ {
  for (let i = 0; i < 48; i++) {
    const q = generate(found);
    if (!used.has(q.prompt)) {
      used.add(q.prompt);
      return q;
    }
  }
  used.clear();
  const q = generate(found);
  used.add(q.prompt);
  return q;
}

export function tempFromDist(d: number): import("./types").TempBand {
  if (d < 2.6) return "burning";
  if (d < 5.5) return "hot";
  if (d < 10) return "warm";
  if (d < 16) return "lukewarm";
  if (d < 26) return "chilly";
  if (d < 40) return "cold";
  return "freezing";
}
