import { useEffect, useRef, useState } from "react";
import {
  BookOpen,
  HelpCircle,
  Pause,
  Play,
  Sparkles,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { LEVELS } from "./levels";
import { useGame } from "./store";
import { TEMP_LABEL, type DressId } from "./types";
import { sfx, unlockAudio, setMuted } from "./audio";
import { touchMove, triggerJump } from "./input";
import { cn } from "@/lib/utils";

const DRESS_OPTS: { id: DressId; label: string; hex: string }[] = [
  { id: "coral", label: "Coral", hex: "#d45a4a" },
  { id: "sky", label: "Sky", hex: "#4f93c4" },
  { id: "mint", label: "Mint", hex: "#3f9a6b" },
  { id: "rose", label: "Rose", hex: "#c46b8a" },
  { id: "apricot", label: "Apricot", hex: "#d4894a" },
];

const TEMP_TINT: Record<string, string> = {
  freezing: "text-cold",
  cold: "text-cold",
  chilly: "text-accent-2",
  lukewarm: "text-ink-soft",
  warm: "text-warm",
  hot: "text-warm",
  burning: "text-accent",
};

function Panel({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "rounded-xl border border-line bg-surface text-ink shadow-[0_18px_40px_-24px_rgb(42_33_24_/_0.45)]",
        className,
      )}
    >
      {children}
    </div>
  );
}

function Btn({
  children,
  onClick,
  variant = "primary",
  className,
  disabled,
  type = "button",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost";
  className?: string;
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "inline-flex min-h-11 items-center justify-center rounded-md px-5 text-base font-semibold tracking-tight transition-transform duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] enabled:active:scale-[0.98] disabled:opacity-50",
        variant === "primary" && "bg-accent text-accent-fg",
        variant === "secondary" && "border border-line bg-surface-2 text-ink",
        variant === "ghost" && "bg-transparent text-ink",
        className,
      )}
    >
      {children}
    </button>
  );
}

function TitleScreen() {
  const playerName = useGame((s) => s.playerName);
  const dress = useGame((s) => s.dress);
  const unlocked = useGame((s) => s.unlocked);
  const collected = useGame((s) => s.collected);
  const startLevel = useGame((s) => s.startLevel);
  const setName = useGame((s) => s.setName);
  const setDress = useGame((s) => s.setDress);
  const [help, setHelp] = useState(false);

  return (
    <div className="pointer-events-auto flex h-full w-full flex-col items-center justify-end overflow-y-auto bg-ink/25 p-4 pb-6 pt-10 sm:justify-center sm:pb-10">
      <Panel className="w-full max-w-lg p-5 sm:p-7">
        <p className="text-sm font-semibold tracking-wide text-ink-soft">v1</p>
        <h1 className="mt-1 font-display text-3xl font-semibold leading-tight tracking-tight text-ink sm:text-4xl">
          Sloanie's World
        </h1>
        <p className="mt-2 text-base leading-relaxed text-ink-soft">
          Help Sloan hunt hidden dumplings across giant parks, then solve a little math to keep
          each one. Parks unlock one at a time.
        </p>

        <label className="mt-5 block text-sm font-semibold text-ink">
          Explorer name
          <input
            value={playerName}
            onChange={(e) => setName(e.target.value.slice(0, 18))}
            placeholder="Sloan"
            className="mt-1.5 block h-11 w-full rounded-sm border border-line bg-bg px-3 text-base text-ink outline-none ring-accent/40 placeholder:text-muted focus:ring-2"
          />
        </label>

        <p className="mt-4 text-sm font-semibold text-ink">Dress</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {DRESS_OPTS.map((o) => (
            <button
              key={o.id}
              type="button"
              aria-label={o.label}
              onClick={() => setDress(o.id)}
              className={cn(
                "size-10 rounded-full border-2",
                dress === o.id ? "border-ink" : "border-line",
              )}
              style={{ background: o.hex }}
            />
          ))}
        </div>

        <div className="mt-5 grid gap-2">
          {LEVELS.map((lv, i) => {
            const locked = i > unlocked;
            const found = collected[i]?.length ?? 0;
            return (
              <button
                key={lv.id}
                type="button"
                disabled={locked}
                onClick={() => {
                  unlockAudio();
                  sfx.click();
                  startLevel(i);
                }}
                className={cn(
                  "flex min-h-14 items-center justify-between rounded-md border px-4 text-left",
                  locked
                    ? "border-line bg-surface-2 text-muted"
                    : "border-line bg-bg text-ink hover:border-ink/30",
                )}
              >
                <span>
                  <span className="block font-display text-lg font-medium">
                    {locked ? "Locked park" : lv.name}
                  </span>
                  <span className="block text-sm text-ink-soft">
                    {locked
                      ? "Finish the park before this one"
                      : `${lv.tagline}  ·  ${found}/${lv.dumplings.length} found`}
                  </span>
                </span>
                {!locked && i === 0 && (
                  <span className="rounded-full bg-accent px-3 py-1 text-sm font-semibold text-accent-fg">
                    Start
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <Btn variant="secondary" onClick={() => setHelp((v) => !v)} className="gap-2">
            <HelpCircle className="size-4" />
            How to play
          </Btn>
        </div>
        {help && (
          <ul className="mt-3 space-y-1.5 text-sm leading-relaxed text-ink-soft">
            <li>Walk with W A S D or the stick. Jump with Space.</li>
            <li>Drag the screen to look around. Q and E also turn the camera.</li>
            <li>
              On a controller: left stick walk, right stick look, A jump, X collect, Y hint,
              LB/RB turn camera, Start pause.
            </li>
            <li>The temperature tells you if a dumpling is close.</li>
            <li>When you are next to one, press Collect and answer the math.</li>
            <li>Miss twice and the dumpling runs away to a new hiding spot.</li>
            <li>Hints point to a region, not the exact hiding spot. Use them sparingly.</li>
          </ul>
        )}
      </Panel>
    </div>
  );
}

function HUD() {
  const temp = useGame((s) => s.temp);
  const nearestName = useGame((s) => s.nearestName);
  const nearCollect = useGame((s) => s.nearCollect);
  const collected = useGame((s) => s.collected);
  const levelIndex = useGame((s) => s.levelIndex);
  const hintsLeft = useGame((s) => s.hintsLeft);
  const hintText = useGame((s) => s.hintText);
  const muted = useGame((s) => s.muted);
  const journalOpen = useGame((s) => s.journalOpen);
  const playerName = useGame((s) => s.playerName);
  const pause = useGame((s) => s.pause);
  const toggleMute = useGame((s) => s.toggleMute);
  const toggleJournal = useGame((s) => s.toggleJournal);
  const useHint = useGame((s) => s.useHint);
  const requestInteract = useGame((s) => s.requestInteract);
  const fleeNotice = useGame((s) => s.fleeNotice);
  const clearFleeNotice = useGame((s) => s.clearFleeNotice);
  const clearHint = useGame((s) => s.clearHint);
  const phase = useGame((s) => s.phase);
  const level = LEVELS[levelIndex]!;
  const found = collected[levelIndex]?.length ?? 0;

  const close = temp === "warm" || temp === "hot" || temp === "burning";
  const status = fleeNotice
    ? fleeNotice
    : nearCollect
      ? `${playerName ? `${playerName}, ` : ""}this is ${nearestName}. Press Collect!`
      : close
        ? "Getting warmer…"
        : "Search the park";

  useEffect(() => {
    if (!fleeNotice) return;
    const t = window.setTimeout(() => clearFleeNotice(), 4200);
    return () => window.clearTimeout(t);
  }, [fleeNotice, clearFleeNotice]);

  useEffect(() => {
    if (!hintText) return;
    const t = window.setTimeout(() => clearHint(), 14000);
    return () => window.clearTimeout(t);
  }, [hintText, clearHint]);

  return (
    <>
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <Panel className="pointer-events-auto px-3 py-2">
          <p className="font-display text-sm font-medium text-ink-soft">{level.name}</p>
          <p className="font-display text-xl font-semibold tabular-nums leading-tight">
            {found}
            <span className="text-ink-soft"> / {level.dumplings.length}</span>
          </p>
          <p className={cn("text-sm font-bold tabular-nums", TEMP_TINT[temp])}>
            {TEMP_LABEL[temp]}
          </p>
        </Panel>
        <div className="pointer-events-auto flex gap-2">
          <IconBtn label="Journal" onClick={toggleJournal}>
            <BookOpen className="size-5" />
          </IconBtn>
          <IconBtn
            label={muted ? "Unmute" : "Mute"}
            onClick={() => {
              toggleMute();
              setMuted(!muted);
            }}
          >
            {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
          </IconBtn>
          <IconBtn label="Pause" onClick={pause}>
            <Pause className="size-5" />
          </IconBtn>
        </div>
      </div>

      {(nearCollect || fleeNotice || close) && (
        <div className="pointer-events-none absolute inset-x-0 top-24 flex justify-center px-3">
          <Panel className="pointer-events-auto relative max-w-sm px-4 py-2 pr-10 text-center">
            <p className="text-sm font-semibold text-ink">{status}</p>
            {fleeNotice && (
              <button
                type="button"
                aria-label="Dismiss"
                onClick={clearFleeNotice}
                className="absolute right-1.5 top-1.5 grid size-8 place-items-center rounded-sm text-ink-soft"
              >
                <X className="size-4" />
              </button>
            )}
          </Panel>
        </div>
      )}

      {hintText && (
        <div className="pointer-events-none absolute inset-x-0 top-40 flex justify-center px-4">
          <Panel className="pointer-events-auto relative max-w-md px-4 py-3 pr-11 text-center text-sm leading-relaxed text-ink">
            {hintText}
            <button
              type="button"
              aria-label="Dismiss hint"
              onClick={clearHint}
              className="absolute right-1.5 top-1.5 grid size-8 place-items-center rounded-sm text-ink-soft"
            >
              <X className="size-4" />
            </button>
          </Panel>
        </div>
      )}

      {phase === "playing" && (
        <div className="pointer-events-none absolute bottom-4 left-0 right-0 z-10 flex items-end justify-between gap-3 px-3 pb-[env(safe-area-inset-bottom)] sm:bottom-6">
          <Joystick />
          <div className="pointer-events-auto flex flex-col items-end gap-2">
            {nearCollect && (
              <Btn onClick={requestInteract} className="min-w-36 shadow-[0_18px_40px_-24px_rgb(42_33_24_/_0.45)]">
                Collect
              </Btn>
            )}
            <Btn
              variant="secondary"
              onClick={useHint}
              disabled={hintsLeft <= 0}
              className="gap-2"
            >
              <Sparkles className="size-4" />
              Hint · {hintsLeft}
            </Btn>
            <button
              type="button"
              aria-label="Jump"
              onPointerDown={(e) => {
                e.preventDefault();
                triggerJump();
              }}
              className="grid size-16 place-items-center rounded-full border border-line bg-surface text-sm font-bold text-ink shadow-[0_18px_40px_-24px_rgb(42_33_24_/_0.45)] sm:hidden"
            >
              Jump
            </button>
          </div>
        </div>
      )}

      {journalOpen && <Journal />}
    </>
  );
}

function IconBtn({
  children,
  onClick,
  label,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="grid size-11 place-items-center rounded-md border border-line bg-surface text-ink shadow-[0_18px_40px_-24px_rgb(42_33_24_/_0.45)]"
    >
      {children}
    </button>
  );
}

function Joystick() {
  const ref = useRef<HTMLDivElement>(null);
  const pid = useRef<number | null>(null);
  useEffect(() => {
    return () => {
      touchMove.x = 0;
      touchMove.z = 0;
    };
  }, []);
  function setFrom(clientX: number, clientY: number) {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    let x = (clientX - cx) / (r.width * 0.42);
    let y = (clientY - cy) / (r.height * 0.42);
    const m = Math.hypot(x, y);
    if (m > 1) {
      x /= m;
      y /= m;
    }
    touchMove.x = x;
    touchMove.z = -y;
  }
  return (
    <div
      ref={ref}
      className="pointer-events-auto relative size-32 rounded-full border border-line bg-surface/80 md:hidden"
      onPointerDown={(e) => {
        pid.current = e.pointerId;
        e.currentTarget.setPointerCapture(e.pointerId);
        setFrom(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (pid.current === e.pointerId) setFrom(e.clientX, e.clientY);
      }}
      onPointerUp={() => {
        pid.current = null;
        touchMove.x = 0;
        touchMove.z = 0;
      }}
      onPointerCancel={() => {
        pid.current = null;
        touchMove.x = 0;
        touchMove.z = 0;
      }}
    >
      <div className="absolute inset-7 rounded-full border border-line/80 bg-surface-2/90" />
    </div>
  );
}

function Journal() {
  const levelIndex = useGame((s) => s.levelIndex);
  const collected = useGame((s) => s.collected[levelIndex] ?? []);
  const setJournal = useGame((s) => s.setJournal);
  const level = LEVELS[levelIndex]!;
  return (
    <div className="pointer-events-auto absolute inset-0 z-30 flex items-center justify-center bg-ink/40 p-4">
      <Panel className="relative max-h-[80dvh] w-full max-w-md overflow-y-auto p-5">
        <button
          type="button"
          aria-label="Close journal"
          className="absolute right-3 top-3 grid size-10 place-items-center rounded-sm text-ink"
          onClick={() => setJournal(false)}
        >
          <X className="size-5" />
        </button>
        <h2 className="font-display text-2xl font-semibold">Dumpling journal</h2>
        <p className="mt-1 text-sm text-ink-soft">
          {collected.length} of {level.dumplings.length} found in {level.name}
        </p>
        <ul className="mt-4 space-y-2">
          {level.dumplings.map((d) => {
            const got = collected.includes(d.id);
            return (
              <li
                key={d.id}
                className="flex items-center gap-3 rounded-md border border-line bg-bg px-3 py-2"
              >
                <span
                  className="size-8 rounded-full border border-line"
                  style={{ background: got ? d.color : "#e2d5c4" }}
                />
                <span>
                  <span className="block font-semibold">{got ? d.name : "Unknown dumpling"}</span>
                  <span className="block text-sm text-ink-soft">
                    {got
                      ? `Found near ${d.region}`
                      : d.hide === "hard"
                        ? "Well hidden"
                        : "Still out there"}
                  </span>
                </span>
              </li>
            );
          })}
        </ul>
      </Panel>
    </div>
  );
}

function Quiz() {
  const quiz = useGame((s) => s.quiz);
  const bumpAttempt = useGame((s) => s.bumpAttempt);
  const markCollected = useGame((s) => s.markCollected);
  const fleeDumpling = useGame((s) => s.fleeDumpling);
  const [shake, setShake] = useState(false);
  const [sel, setSel] = useState(0);
  const pickRef = useRef<(n: number) => void>(() => {});
  const selRef = useRef(0);
  selRef.current = sel;

  function pick(n: number) {
    if (!quiz) return;
    if (n === quiz.q.answer) {
      sfx.correct();
      markCollected(quiz.dumplingId);
    } else if (quiz.attempts >= 1) {
      sfx.wrong();
      sfx.flee();
      fleeDumpling(quiz.dumplingId);
    } else {
      sfx.wrong();
      bumpAttempt();
      setShake(true);
      window.setTimeout(() => setShake(false), 400);
    }
  }
  pickRef.current = pick;

  useEffect(() => {
    let prevA = false;
    let prevUp = false;
    let prevDown = false;
    let raf = 0;
    const loop = () => {
      const pads = navigator.getGamepads?.() ?? [];
      const pad = pads.find((p) => p && p.buttons.length > 0);
      if (pad) {
        const a = Boolean(pad.buttons[0]?.pressed);
        const up = Boolean(pad.buttons[12]?.pressed) || (pad.axes[1] ?? 0) < -0.55;
        const down = Boolean(pad.buttons[13]?.pressed) || (pad.axes[1] ?? 0) > 0.55;
        const n = useGame.getState().quiz?.q.choices.length ?? 3;
        if (up && !prevUp) setSel((s) => (s - 1 + n) % n);
        if (down && !prevDown) setSel((s) => (s + 1) % n);
        if (a && !prevA) {
          const q = useGame.getState().quiz;
          if (q) {
            const i = ((selRef.current % n) + n) % n;
            pickRef.current(q.q.choices[i]!);
          }
        }
        prevA = a;
        prevUp = up;
        prevDown = down;
      }
      raf = window.requestAnimationFrame(loop);
    };
    raf = window.requestAnimationFrame(loop);
    return () => window.cancelAnimationFrame(raf);
  }, []);

  if (!quiz) return null;

  return (
    <div className="pointer-events-auto absolute inset-0 z-30 flex items-center justify-center bg-ink/45 p-4">
      <Panel className={cn("w-full max-w-md p-6", shake && "animate-pulse")}>
        <p className="text-sm font-semibold text-ink-soft">Solve it to keep the dumpling</p>
        <p className="mt-2 font-display text-4xl font-semibold tabular-nums tracking-tight">
          {quiz.q.prompt} = ?
        </p>
        {quiz.q.visual && (
          <div className="mt-4 flex flex-wrap items-center gap-4">
            {quiz.q.visual.map((n, i) => (
              <div key={i} className="flex items-center gap-3">
                {i > 0 && <span className="font-display text-2xl text-ink-soft">+</span>}
                <div className="flex flex-wrap gap-1">
                  {Array.from({ length: n }).map((_, j) => (
                    <span key={j} className="size-4 rounded-full bg-accent/80" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
        <div className="mt-6 grid gap-2">
          {quiz.q.choices.map((c, i) => (
            <button
              key={c}
              type="button"
              onClick={() => pick(c)}
              className={cn(
                "min-h-14 rounded-md border text-2xl font-bold tabular-nums text-ink",
                i === sel % quiz.q.choices.length
                  ? "border-ink bg-surface-2"
                  : "border-line bg-bg",
              )}
            >
              {c}
            </button>
          ))}
        </div>
        {quiz.attempts > 0 && (
          <p className="mt-3 text-sm text-ink-soft">
            Almost. One more miss and it will run away.
          </p>
        )}
        <p className="mt-2 text-xs text-ink-soft">Controller: D-pad to choose, A to answer.</p>
      </Panel>
    </div>
  );
}

function PauseScreen() {
  const resumePlay = useGame((s) => s.resumePlay);
  const toTitle = useGame((s) => s.toTitle);
  return (
    <div className="pointer-events-auto absolute inset-0 z-30 flex items-center justify-center bg-ink/45 p-4">
      <Panel className="w-full max-w-sm p-6 text-center">
        <h2 className="font-display text-3xl font-semibold">Paused</h2>
        <p className="mt-2 text-ink-soft">The dumplings will wait.</p>
        <div className="mt-5 grid gap-2">
          <Btn onClick={resumePlay} className="gap-2">
            <Play className="size-4" />
            Keep hunting
          </Btn>
          <Btn variant="secondary" onClick={toTitle}>
            Back to title
          </Btn>
        </div>
      </Panel>
    </div>
  );
}

function CompleteScreen() {
  const levelIndex = useGame((s) => s.levelIndex);
  const playerName = useGame((s) => s.playerName);
  const nextLevel = useGame((s) => s.nextLevel);
  const replayLevel = useGame((s) => s.replayLevel);
  const toTitle = useGame((s) => s.toTitle);
  const level = LEVELS[levelIndex]!;
  const next = LEVELS[levelIndex + 1];
  return (
    <div className="pointer-events-auto absolute inset-0 z-30 flex items-center justify-center bg-ink/45 p-4">
      <Panel className="w-full max-w-md p-6 text-center">
        <p className="text-sm font-semibold text-ok">Park complete</p>
        <h2 className="mt-1 font-display text-3xl font-semibold">
          {playerName ? `${playerName} found them all` : "Every dumpling found"}
        </h2>
        <p className="mt-2 leading-relaxed text-ink-soft">
          {level.dumplings.length} squishy dumplings rescued from {level.name}. The next park is
          waiting whenever you are.
        </p>
        <div className="mt-5 grid gap-2">
          {next && <Btn onClick={nextLevel}>Play {next.name}</Btn>}
          <Btn variant="secondary" onClick={replayLevel}>
            Hunt this park again
          </Btn>
          <Btn variant="ghost" onClick={toTitle}>
            Title
          </Btn>
        </div>
      </Panel>
    </div>
  );
}

function VictoryScreen() {
  const playerName = useGame((s) => s.playerName);
  const replayLevel = useGame((s) => s.replayLevel);
  const toTitle = useGame((s) => s.toTitle);
  return (
    <div className="pointer-events-auto absolute inset-0 z-30 flex items-center justify-center bg-ink/45 p-4">
      <Panel className="w-full max-w-md p-6 text-center">
        <p className="text-sm font-semibold text-ok">The hunt is over</p>
        <h2 className="mt-1 font-display text-3xl font-semibold">
          Happy birthday{playerName ? `, ${playerName}` : ", Sloan"}
        </h2>
        <p className="mt-2 leading-relaxed text-ink-soft">
          You searched the park, the village, and the castle in the clouds. Every squishy dumpling
          is home.
        </p>
        <div className="mt-5 grid gap-2">
          <Btn onClick={replayLevel}>Play Cloud Castle again</Btn>
          <Btn variant="secondary" onClick={toTitle}>
            Back to title
          </Btn>
        </div>
      </Panel>
    </div>
  );
}

export function Overlays() {
  const phase = useGame((s) => s.phase);
  const muted = useGame((s) => s.muted);

  useEffect(() => {
    setMuted(muted);
  }, [muted]);

  return (
    <div className="overlay-root">
      {phase === "title" && <TitleScreen />}
      {(phase === "playing" || phase === "paused" || phase === "quiz") && <HUD />}
      {phase === "quiz" && <Quiz />}
      {phase === "paused" && <PauseScreen />}
      {phase === "complete" && <CompleteScreen />}
      {phase === "victory" && <VictoryScreen />}
    </div>
  );
}
