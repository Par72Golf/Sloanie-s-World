import type { DressId, HairId } from "./types";

const KEY = "sloanies-world-v1";
const SAVE_VERSION = 1;

export type SaveData = {
  version: number;
  playerName: string;
  dress: DressId;
  hair: HairId;
  unlocked: number;
  collected: string[][];
  muted: boolean;
  levelIndex: number;
};

const DEFAULT: SaveData = {
  version: SAVE_VERSION,
  playerName: "Sloan",
  dress: "coral",
  hair: "brown",
  unlocked: 0,
  collected: [[], [], []],
  muted: false,
  levelIndex: 0,
};

function migrate(raw: SaveData): SaveData {
  const s = { ...DEFAULT, ...raw };
  if (!Array.isArray(s.collected) || s.collected.length < 3) {
    s.collected = [[], [], []];
  }
  s.collected = [0, 1, 2].map((i) =>
    Array.isArray(s.collected[i]) ? s.collected[i]!.slice() : [],
  );
  s.version = SAVE_VERSION;
  return s;
}

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT, collected: [[], [], []] };
    const parsed = JSON.parse(raw) as SaveData;
    return migrate(parsed);
  } catch {
    return { ...DEFAULT, collected: [[], [], []] };
  }
}

export function persistSave(data: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify({ ...data, version: SAVE_VERSION }));
  } catch {
    /* private mode / quota */
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}
