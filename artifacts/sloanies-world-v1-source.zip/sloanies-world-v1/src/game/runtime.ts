import * as THREE from "three";
import { animateGirl, makeGirl, makeSky } from "./meshes";
import { OutlineEffect } from "three/addons/effects/OutlineEffect.js";
import { buildWorld, disposeWorld, type BuiltWorld, type DumplingHandle } from "./world-build";
import {
  bindInput,
  clearInjectedKeys,
  consumeJumpTap,
  consumeLook,
  consumePadHint,
  consumePadInteract,
  consumePadJournal,
  consumePadPause,
  getMoveAxes,
  isDown,
  look,
  padCamLeft,
  padCamRight,
  pollGamepad,
  setInjectedKeys,
  wantsInteract,
} from "./input";
import { inCircle, moveAndCollide, type Capsule } from "./collision";
import { levelByIndex } from "./levels";
import { makeQuestion, resetQuizBank, tempFromDist } from "./math-quiz";
import { sfx, unlockAudio } from "./audio";
import { useGame } from "./store";
import { DRESS, HAIR, type LevelDef } from "./types";

const WALK = 6.4;
const JUMP = 11.2;
const GRAVITY = 23;
const PLAYER_H = 1.62;
const PLAYER_W = 0.34;
const FIXED = 1 / 60;
const COLLECT_R = 2.15;

function pickFleePos(
  homes: [number, number, number][],
  occupied: [number, number, number][],
  playerX: number,
  playerZ: number,
  current: [number, number, number],
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number },
): [number, number, number] {
  const order = homes.map((_, i) => i).sort(() => Math.random() - 0.5);
  for (const i of order) {
    const h = homes[i]!;
    const x = h[0] + (Math.random() - 0.5) * 5;
    const z = h[2] + (Math.random() - 0.5) * 5;
    if (Math.hypot(x - playerX, z - playerZ) < 16) continue;
    if (Math.hypot(x - current[0], z - current[2]) < 12) continue;
    if (occupied.some((o) => Math.hypot(x - o[0], z - o[2]) < 4.5)) continue;
    const cx = Math.min(bounds.maxX - 3, Math.max(bounds.minX + 3, x));
    const cz = Math.min(bounds.maxZ - 3, Math.max(bounds.minZ + 3, z));
    return [cx, h[1], cz];
  }
  let best = current;
  let bestD = -1;
  for (const h of homes) {
    const dist = Math.hypot(h[0] - playerX, h[2] - playerZ);
    if (dist > bestD) {
      bestD = dist;
      best = h;
    }
  }
  return [best[0], best[1], best[2]];
}

type Puff = { mesh: THREE.Mesh; vx: number; vy: number; vz: number; life: number };

export class GameRuntime {
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  hemi: THREE.HemisphereLight;
  sun: THREE.DirectionalLight;
  fill: THREE.DirectionalLight;
  sky: THREE.Mesh;
  blob: THREE.Mesh;
  outline: OutlineEffect;
  girl: THREE.Group;
  world: BuiltWorld | null = null;
  level: LevelDef;
  cap: Capsule = { x: 0, y: 0, z: 0, hw: PLAYER_W, h: PLAYER_H, hd: PLAYER_W };
  yaw = 0;
  cameraYaw = 0;
  velY = 0;
  speed = 0;
  grounded = true;
  coyote = 0;
  acc = 0;
  clock = 0;
  last = performance.now();
  running = false;
  disposed = false;
  hudT = 0;
  stepT = 0;
  lastInteract = 0;
  lastHint = 0;
  lastFlee = 0;
  lastLevel = -1;
  lastDress = "";
  lastHair = "";
  puffs: Puff[] = [];
  highlightUntil = 0;
  highlighted: DumplingHandle | null = null;
  camPos = new THREE.Vector3();
  camTarget = new THREE.Vector3();
  wish = new THREE.Vector3();
  fwd = new THREE.Vector3();
  right = new THREE.Vector3();
  lookAt = new THREE.Vector3();
  pointerId: number | null = null;
  lastPx = 0;
  lastPy = 0;

  constructor(public canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(canvas.clientWidth || 1280, canvas.clientHeight || 800, false);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.14;

    this.scene = new THREE.Scene();
    this.level = levelByIndex(0);
    this.scene.fog = new THREE.Fog("#c5e0f2", 48, this.level.fogFar);

    this.camera = new THREE.PerspectiveCamera(58, 1, 0.1, 320);
    this.sky = makeSky();
    this.sky.userData.outlineParameters = { visible: false };
    this.scene.add(this.sky);

    this.hemi = new THREE.HemisphereLight("#d4eefe", "#7aaa58", 0.95);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight("#fff3d0", 1.55);
    this.sun.position.set(28, 46, 16);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.camera.near = 2;
    this.sun.shadow.camera.far = 110;
    this.sun.shadow.camera.left = -38;
    this.sun.shadow.camera.right = 38;
    this.sun.shadow.camera.top = 38;
    this.sun.shadow.camera.bottom = -38;
    this.sun.shadow.bias = -0.0006;
    this.sun.shadow.normalBias = 0.04;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);
    this.fill = new THREE.DirectionalLight("#b7d8ff", 0.32);
    this.fill.position.set(-18, 18, -12);
    this.scene.add(this.fill);
    this.scene.add(new THREE.AmbientLight("#fff4e8", 0.28));

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const envScene = new THREE.Scene();
    envScene.background = new THREE.Color("#9fd0f0");
    envScene.add(new THREE.HemisphereLight("#e7f4ff", "#88b86a", 1));
    this.scene.environment = pmrem.fromScene(envScene, 0.04).texture;
    this.scene.environmentIntensity = 0.42;
    pmrem.dispose();

    const st = useGame.getState();
    this.girl = makeGirl("#f3c6a8", HAIR.brown, DRESS[st.dress]);
    this.girl.castShadow = true;
    this.scene.add(this.girl);
    this.blob = new THREE.Mesh(
      new THREE.CircleGeometry(0.55, 20),
      new THREE.MeshBasicMaterial({
        color: "#2a2118",
        transparent: true,
        opacity: 0.22,
        depthWrite: false,
      }),
    );
    this.blob.rotation.x = -Math.PI / 2;
    this.blob.position.y = 0.03;
    this.blob.userData.outlineParameters = { visible: false };
    this.scene.add(this.blob);

    this.outline = new OutlineEffect(this.renderer, {
      defaultThickness: 0.0048,
      defaultColor: [0.16, 0.1, 0.07],
      defaultAlpha: 0.85,
    });
    this.lastDress = st.dress;
    this.lastHair = st.hair;

    bindInput();
    this.bindCanvasLook();
    this.loadLevel(st.levelIndex);
    this.installProbe();
    this.resize();
  }

  bindCanvasLook() {
    const el = this.canvas;
    el.addEventListener("pointerdown", (e) => {
      if (e.button !== 0 && e.pointerType === "mouse") return;
      const st = useGame.getState();
      if (st.phase !== "playing" && st.phase !== "title") return;
      if (e.pointerType === "touch" && e.clientX < window.innerWidth * 0.42) return;
      this.pointerId = e.pointerId;
      this.lastPx = e.clientX;
      this.lastPy = e.clientY;
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    });
    el.addEventListener("pointermove", (e) => {
      if (this.pointerId !== e.pointerId) return;
      look.dx += e.clientX - this.lastPx;
      look.dy += e.clientY - this.lastPy;
      this.lastPx = e.clientX;
      this.lastPy = e.clientY;
    });
    const up = (e: PointerEvent) => {
      if (this.pointerId === e.pointerId) this.pointerId = null;
    };
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
  }

  installProbe() {
    window.__controlsTest = {
      getYaw: () => this.yaw,
      getSpeed: () => this.speed,
      getGirlRot: () => this.girl.rotation.y,
      getCamYaw: () => this.cameraYaw,
      setKeys: (codes: string[]) => {
        if (codes.length === 0) clearInjectedKeys();
        else setInjectedKeys(codes);
      },
    };
    window.__gameTest = {
      teleport: (x: number, y: number, z: number) => {
        this.cap.x = x;
        this.cap.y = y;
        this.cap.z = z;
      },
      getPos: () => ({ x: this.cap.x, y: this.cap.y, z: this.cap.z }),
      nearest: () => this.nearestUnfound()?.def.id ?? null,
    };
  }

  loadLevel(index: number) {
    if (this.world) {
      this.scene.remove(this.world.group);
      disposeWorld(this.world);
    }
    this.level = levelByIndex(index);
    resetQuizBank();
    this.world = buildWorld(this.level);
    this.scene.add(this.world.group);
    this.world.ground.userData.outlineParameters = { visible: false };
    this.scene.fog = new THREE.Fog("#c5e0f2", 48, this.level.fogFar);
    this.cap.x = this.level.spawn[0];
    this.cap.y = this.level.spawn[1];
    this.cap.z = this.level.spawn[2];
    this.yaw = this.level.spawnYaw;
    this.cameraYaw = this.level.spawnYaw;
    this.velY = 0;
    this.speed = 0;
    this.grounded = true;
    this.lastLevel = index;
    const collected = useGame.getState().collected[index] ?? [];
    for (const d of this.world.dumplings) {
      const got = collected.includes(d.def.id);
      d.group.visible = !got;
      d.spark.visible = !got;
      d.beam.visible = !got;
    }
    this.syncCamera(true);
  }

  rebuildGirl() {
    const st = useGame.getState();
    this.scene.remove(this.girl);
    this.girl = makeGirl("#f3c6a8", HAIR.brown, DRESS[st.dress]);
    this.scene.add(this.girl);
    this.lastDress = st.dress;
    this.lastHair = st.hair;
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.last = performance.now();
    this.renderer.setAnimationLoop((t) => this.frame(t));
  }

  stop() {
    this.running = false;
    this.renderer.setAnimationLoop(null);
  }

  dispose() {
    this.disposed = true;
    this.stop();
    if (this.world) disposeWorld(this.world);
    this.renderer.dispose();
    delete window.__controlsTest;
    delete window.__gameTest;
  }

  resize() {
    const parent = this.canvas.parentElement;
    const w = parent?.clientWidth || window.innerWidth;
    const h = parent?.clientHeight || window.innerHeight;
    this.camera.aspect = Math.max(0.4, w / Math.max(1, h));
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
    this.outline.setSize(w, h);
  }

  nearestUnfound(): DumplingHandle | null {
    if (!this.world) return null;
    const collected = useGame.getState().collected[useGame.getState().levelIndex] ?? [];
    let best: DumplingHandle | null = null;
    let bestD = Infinity;
    for (const d of this.world.dumplings) {
      if (collected.includes(d.def.id) || !d.group.visible) continue;
      const dx = d.def.pos[0] - this.cap.x;
      const dz = d.def.pos[2] - this.cap.z;
      const dy = d.def.pos[1] - this.cap.y;
      const dist = Math.hypot(dx, dy, dz);
      if (dist < bestD) {
        bestD = dist;
        best = d;
      }
    }
    return best;
  }

  applyHint() {
    const d = this.nearestUnfound();
    if (!d) {
      useGame.getState().setHint("You already found every dumpling here.", null);
      return;
    }
    this.highlighted = d;
    this.highlightUntil = this.clock + 22;
    (d.beam.material as THREE.MeshStandardMaterial).opacity = 0.55;
    d.spark.intensity = 2.2;
    d.spark.distance = 9;
    useGame.getState().setHint(d.def.hint, d.def.id);
    sfx.hint();
  }

  relocateDumpling(id: string) {
    if (!this.world) return;
    const d = this.world.dumplings.find((x) => x.def.id === id);
    if (!d) return;
    const collected = useGame.getState().collected[useGame.getState().levelIndex] ?? [];
    const occupied = this.world.dumplings
      .filter((x) => x.def.id !== id && !collected.includes(x.def.id))
      .map((x) => x.def.pos);
    const homes = this.level.dumplings.map((x) => x.pos);
    const next = pickFleePos(
      homes,
      occupied,
      this.cap.x,
      this.cap.z,
      d.def.pos,
      this.level.bounds,
    );
    this.burst(d.def.pos[0], d.def.pos[1], d.def.pos[2], d.def.color);
    d.def.pos[0] = next[0];
    d.def.pos[1] = next[1];
    d.def.pos[2] = next[2];
    d.def.hint = "It dashed to a new hiding spot. Follow hot and cold.";
    d.group.position.set(next[0], next[1], next[2]);
    d.spark.position.set(next[0], next[1] + 0.6, next[2]);
    d.beam.position.set(next[0], next[1] + 3, next[2]);
    d.spark.intensity = 0.8;
    (d.beam.material as THREE.MeshStandardMaterial).opacity = 0.28;
    this.highlighted = null;
    this.highlightUntil = 0;
  }

  tryCollect() {
    const st = useGame.getState();
    if (st.phase !== "playing") return;
    const d = this.nearestUnfound();
    if (!d) return;
    const dist = Math.hypot(
      d.def.pos[0] - this.cap.x,
      d.def.pos[1] - (this.cap.y + 0.8),
      d.def.pos[2] - this.cap.z,
    );
    if (dist > COLLECT_R) return;
    const found = (st.collected[st.levelIndex] ?? []).length;
    st.openQuiz(d.def.id, makeQuestion(st.levelIndex, found));
  }

  burst(x: number, y: number, z: number, color: string) {
    const geo = new THREE.SphereGeometry(0.1, 6, 6);
    const mat = new THREE.MeshBasicMaterial({ color });
    for (let i = 0; i < 14; i++) {
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x, y + 0.3, z);
      this.scene.add(mesh);
      this.puffs.push({
        mesh,
        vx: (Math.random() - 0.5) * 4,
        vy: 2 + Math.random() * 3,
        vz: (Math.random() - 0.5) * 4,
        life: 0.7 + Math.random() * 0.3,
      });
    }
  }

  onCollected(id: string) {
    if (!this.world) return;
    const d = this.world.dumplings.find((x) => x.def.id === id);
    if (!d) return;
    d.group.visible = false;
    d.spark.visible = false;
    d.beam.visible = false;
    this.burst(d.def.pos[0], d.def.pos[1], d.def.pos[2], d.def.color);
    sfx.collect();
    const st = useGame.getState();
    const have = (st.collected[st.levelIndex] ?? []).length;
    const total = this.level.dumplings.length;
    if (have >= total) {
      sfx.win();
      st.completeLevel();
    }
  }

  syncCamera(snap = false) {
    const title = useGame.getState().phase === "title";
    const cfX = -Math.sin(this.cameraYaw);
    const cfZ = -Math.cos(this.cameraYaw);
    const dist = title ? 4.6 : 7.4;
    const height = title ? 1.7 : 3.9;
    const desired = this.camPos;
    desired.set(
      this.cap.x - cfX * dist,
      this.cap.y + height,
      this.cap.z - cfZ * dist,
    );
    if (this.world && !title) {
      const boxes = this.world.colliders;
      for (let i = 1; i <= 8; i++) {
        const t = i / 8;
        const x = this.cap.x + (desired.x - this.cap.x) * t;
        const y = this.cap.y + 1.2 + (desired.y - this.cap.y - 1.2) * t;
        const z = this.cap.z + (desired.z - this.cap.z) * t;
        let hit = false;
        for (const b of boxes) {
          if (x > b.minX - 0.35 && x < b.maxX + 0.35 && y > b.minY && y < b.maxY && z > b.minZ - 0.35 && z < b.maxZ + 0.35) {
            const u = Math.max(0.18, (i - 1) / 8);
            desired.set(
              this.cap.x + (desired.x - this.cap.x) * u,
              this.cap.y + 1.2 + (desired.y - this.cap.y - 1.2) * u,
              this.cap.z + (desired.z - this.cap.z) * u,
            );
            hit = true;
            break;
          }
        }
        if (hit) break;
      }
    }
    if (snap) this.camera.position.copy(desired);
    else {
      const k = 1 - Math.exp(-5.2 * FIXED);
      this.camera.position.lerp(desired, k);
    }
    this.lookAt.set(this.cap.x, this.cap.y + (title ? 0.2 : 1.25), this.cap.z);
    this.camera.lookAt(this.lookAt);
  }

  physics(dt: number) {
    const st = useGame.getState();
    const qa = Boolean(window.__controlsTest && (isDown("KeyW") || isDown("KeyA") || isDown("KeyD") || isDown("KeyS")));
    const live = st.phase === "playing" || (st.phase === "title" && qa);
    if (!live) consumeJumpTap();

    const lookDelta = consumeLook();
    if (st.phase === "title" && !qa) {
      this.cameraYaw += dt * 0.18;
    } else {
      this.cameraYaw -= lookDelta.dx * 0.0055;
      if (isDown("KeyQ") || padCamLeft()) this.cameraYaw += dt * 1.6;
      if (isDown("KeyE") || padCamRight()) this.cameraYaw -= dt * 1.6;
    }

    const axes = getMoveAxes();
    pollGamepad(axes);

    this.fwd.set(-Math.sin(this.cameraYaw), 0, -Math.cos(this.cameraYaw));
    this.right.set(Math.cos(this.cameraYaw), 0, -Math.sin(this.cameraYaw));
    this.wish.set(0, 0, 0);
    if (live) {
      this.wish.addScaledVector(this.fwd, axes.z);
      this.wish.addScaledVector(this.right, axes.x);
    }
    const wishLen = this.wish.length();
    if (wishLen > 1) this.wish.multiplyScalar(1 / wishLen);

    if (wishLen > 0.05) {
      const targetYaw = Math.atan2(-this.wish.x, -this.wish.z);
      let diff = targetYaw - this.yaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      const turn = 1 - Math.exp(-14 * dt);
      this.yaw += diff * turn;
    }

    let vx = 0;
    let vz = 0;
    const inWater = (this.level.water ?? []).some((w) =>
      inCircle(this.cap.x, this.cap.z, w.x, w.z, w.r),
    );
    const speedMul = inWater ? 0.48 : 1;
    if (wishLen > 0.05) {
      vx = this.wish.x * WALK * speedMul;
      vz = this.wish.z * WALK * speedMul;
    }
    this.speed = Math.hypot(vx, vz);

    if (this.grounded) this.coyote = 0.12;
    else this.coyote = Math.max(0, this.coyote - dt);

    const jump = live && consumeJumpTap();
    if (jump && this.coyote > 0) {
      this.velY = JUMP;
      this.grounded = false;
      this.coyote = 0;
      sfx.jump();
    }

    this.velY -= GRAVITY * dt;
    const moved = moveAndCollide(
      this.cap,
      vx,
      this.velY,
      vz,
      this.world?.colliders ?? [],
      dt,
      this.level.groundY,
    );
    this.velY = moved.vy;
    this.grounded = moved.grounded;

    this.sun.position.set(this.cap.x + 24, 48, this.cap.z + 14);
    this.sun.target.position.set(this.cap.x, 1, this.cap.z);
    this.sun.target.updateMatrixWorld();
    this.blob.position.set(this.cap.x, this.cap.y + 0.03, this.cap.z);
    (this.blob.material as THREE.MeshBasicMaterial).opacity = this.grounded ? 0.22 : 0.08;

    const b = this.level.bounds;
    this.cap.x = Math.min(b.maxX, Math.max(b.minX, this.cap.x));
    this.cap.z = Math.min(b.maxZ, Math.max(b.minZ, this.cap.z));

    if (this.level.voidY != null && this.cap.y < this.level.voidY) {
      this.cap.x = this.level.spawn[0];
      this.cap.y = this.level.spawn[1] + 0.4;
      this.cap.z = this.level.spawn[2];
      this.velY = 0;
    }

    this.girl.position.set(this.cap.x, this.cap.y, this.cap.z);
    this.girl.rotation.y =
      st.phase === "title" && !qa ? this.cameraYaw : this.yaw + Math.PI;
    animateGirl(this.girl, this.speed > 0.4 && this.grounded, this.grounded, this.clock, dt);

    if (this.speed > 1 && this.grounded) {
      this.stepT += dt;
      if (this.stepT > 0.34) {
        this.stepT = 0;
        sfx.step();
      }
    }

    this.syncCamera(false);
    this.sun.position.set(this.cap.x + 28, 42, this.cap.z + 16);
    this.sun.target.position.set(this.cap.x, 0, this.cap.z);
    this.sun.target.updateMatrixWorld();
  }

  animateWorld(dt: number) {
    if (!this.world) return;
    const collected = useGame.getState().collected[useGame.getState().levelIndex] ?? [];
    for (const d of this.world.dumplings) {
      if (!d.group.visible) continue;
      d.group.position.y = d.def.pos[1] + Math.sin(this.clock * 2.3 + d.phase) * 0.1;
      d.group.rotation.y += dt * 0.7;
      const dx = d.def.pos[0] - this.cap.x;
      const dz = d.def.pos[2] - this.cap.z;
      const dist = Math.hypot(dx, dz);
      const easy = d.def.hide === "easy";
      const mid = d.def.hide === "medium";
      const sparkleRange = easy ? 28 : mid ? 11 : 4.5;
      const highlighted = this.highlighted === d && this.clock < this.highlightUntil;
      d.spark.position.copy(d.group.position);
      d.spark.position.y += 0.55;
      d.spark.intensity = highlighted ? 2.4 : 0.7;
      const beamMat = d.beam.material as THREE.MeshStandardMaterial;
      beamMat.opacity = highlighted ? 0.55 : 0.24;
      if (collected.includes(d.def.id)) d.group.visible = false;
    }
    if (this.highlighted && this.clock > this.highlightUntil) {
      this.highlighted = null;
    }

    for (let i = this.puffs.length - 1; i >= 0; i--) {
      const p = this.puffs[i]!;
      p.life -= dt;
      p.vy -= 6 * dt;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      p.mesh.scale.setScalar(Math.max(0.01, p.life));
      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.puffs.splice(i, 1);
      }
    }

    for (const mat of this.world.waterMats) {
      mat.uniforms.uTime.value = this.clock;
    }

    this.world.group.traverse((obj) => {
      if (obj.userData.cloudDrift) {
        obj.position.x += Math.sin(this.clock * 0.15 + obj.position.z) * dt * 0.15;
      }
    });
  }

  hud(dt: number) {
    this.hudT += dt;
    if (this.hudT < 0.12) return;
    this.hudT = 0;
    const d = this.nearestUnfound();
    if (!d) {
      useGame.getState().setHud({
        temp: "burning",
        nearestName: null,
        nearestDist: 0,
        nearCollect: false,
      });
      return;
    }
    const distXZ = Math.hypot(d.def.pos[0] - this.cap.x, d.def.pos[2] - this.cap.z);
    const dist3 = Math.hypot(
      d.def.pos[0] - this.cap.x,
      d.def.pos[1] - (this.cap.y + 0.8),
      d.def.pos[2] - this.cap.z,
    );
    useGame.getState().setHud({
      temp: tempFromDist(distXZ),
      nearestName: d.def.name,
      nearestDist: distXZ,
      nearCollect: dist3 <= COLLECT_R,
    });
  }

  frame(now: number) {
    if (this.disposed) return;
    const raw = Math.min(0.1, (now - this.last) / 1000);
    this.last = now;
    this.clock += raw;

    const st = useGame.getState();
    if (st.levelIndex !== this.lastLevel) this.loadLevel(st.levelIndex);
    if (st.dress !== this.lastDress || st.hair !== this.lastHair) this.rebuildGirl();
    if (st.interactGen !== this.lastInteract) {
      this.lastInteract = st.interactGen;
      this.tryCollect();
    }
    if (st.hintGen !== this.lastHint) {
      this.lastHint = st.hintGen;
      this.applyHint();
    }
    if (st.fleeGen !== this.lastFlee) {
      this.lastFlee = st.fleeGen;
      if (st.fleeId) this.relocateDumpling(st.fleeId);
    }
    if (st.phase === "playing" && (wantsInteract() || consumePadInteract())) this.tryCollect();
    else consumePadInteract();

    const pauseEdge = consumePadPause();
    if (st.phase === "playing" && (isDown("Escape") || pauseEdge)) st.pause();
    else if (st.phase === "paused" && pauseEdge) st.resumePlay();

    if (st.phase === "playing" && consumePadHint()) st.useHint();
    else consumePadHint();
    if (st.phase === "playing" && consumePadJournal()) st.toggleJournal();
    else consumePadJournal();

    const collectedNow = st.collected[st.levelIndex] ?? [];
    if (this.world) {
      for (const d of this.world.dumplings) {
        const got = collectedNow.includes(d.def.id);
        if (got && d.group.visible) this.onCollected(d.def.id);
        if (!got && !d.group.visible) {
          d.group.visible = true;
          d.spark.visible = true;
          d.beam.visible = true;
        }
      }
    }

    this.acc += raw;
    let steps = 0;
    while (this.acc >= FIXED && steps < 5) {
      this.physics(FIXED);
      this.acc -= FIXED;
      steps++;
    }
    this.animateWorld(raw);
    this.hud(raw);
    this.outline.render(this.scene, this.camera);
  }
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      getGirlRot: () => number;
      getCamYaw: () => number;
      setKeys: (codes: string[]) => void;
    };
    __gameTest?: {
      teleport: (x: number, y: number, z: number) => void;
      getPos: () => { x: number; y: number; z: number };
      nearest: () => string | null;
    };
  }
}
