import * as THREE from "three";

const boxGeo = new THREE.BoxGeometry(1, 1, 1);
const sphereGeo = new THREE.SphereGeometry(1, 14, 12);
const cylGeo = new THREE.CylinderGeometry(1, 1, 1, 10);
const coneGeo = new THREE.ConeGeometry(1, 1, 8);
const cone4Geo = new THREE.ConeGeometry(1, 1, 4);

const mats = new Map<string, THREE.MeshStandardMaterial>();

export function lam(
  color: string,
  extras?: { transparent?: boolean; opacity?: number; emissive?: string; roughness?: number },
) {
  const key = `${color}|${extras?.opacity ?? 1}|${extras?.emissive ?? ""}|${extras?.roughness ?? 0.58}`;
  let m = mats.get(key);
  if (!m) {
    m = new THREE.MeshStandardMaterial({
      color,
      roughness: extras?.roughness ?? 0.58,
      metalness: 0.04,
      transparent: extras?.transparent ?? (extras?.opacity != null && extras.opacity < 1),
      opacity: extras?.opacity ?? 1,
      emissive: extras?.emissive ? new THREE.Color(extras.emissive) : undefined,
      emissiveIntensity: extras?.emissive ? 0.4 : 0,
    });
    mats.set(key, m);
  }
  return m;
}

function mesh(
  geo: THREE.BufferGeometry,
  color: string,
  sx: number,
  sy: number,
  sz: number,
  x: number,
  y: number,
  z: number,
  shadow = true,
) {
  const o = new THREE.Mesh(geo, lam(color));
  o.scale.set(sx, sy, sz);
  o.position.set(x, y, z);
  o.castShadow = shadow;
  o.receiveShadow = true;
  return o;
}

export function makeGirl(skin: string, hair: string, dress: string) {
  const root = new THREE.Group();
  const shoe = "#f4f0ea";
  const sock = "#fff8f0";
  const eye = "#5a3317";
  const white = "#f7f3ee";
  const blush = "#e8a090";

  const hips = new THREE.Group();
  hips.position.y = 0.72;
  root.add(hips);

  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.16, 0, 0);
  leftLeg.add(mesh(cylGeo, dress, 0.13, 0.4, 0.13, 0, -0.16, 0));
  leftLeg.add(mesh(cylGeo, sock, 0.12, 0.22, 0.12, 0, -0.44, 0));
  leftLeg.add(mesh(sphereGeo, shoe, 0.15, 0.1, 0.2, 0, -0.62, 0.05));
  hips.add(leftLeg);

  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.16, 0, 0);
  rightLeg.add(mesh(cylGeo, dress, 0.13, 0.4, 0.13, 0, -0.16, 0));
  rightLeg.add(mesh(cylGeo, sock, 0.12, 0.22, 0.12, 0, -0.44, 0));
  rightLeg.add(mesh(sphereGeo, shoe, 0.15, 0.1, 0.2, 0, -0.62, 0.05));
  hips.add(rightLeg);

  const skirt = new THREE.Mesh(coneGeo, lam(dress, { roughness: 0.5 }));
  skirt.scale.set(0.52, 0.55, 0.48);
  skirt.position.y = 0.92;
  skirt.castShadow = true;
  skirt.receiveShadow = true;
  root.add(skirt);
  root.add(mesh(cylGeo, dress, 0.28, 0.48, 0.22, 0, 1.22, 0));
  root.add(mesh(sphereGeo, dress, 0.3, 0.16, 0.24, 0, 1.42, 0));

  const leftArm = new THREE.Group();
  leftArm.position.set(-0.4, 1.34, 0);
  leftArm.add(mesh(cylGeo, dress, 0.1, 0.34, 0.1, 0, -0.1, 0));
  leftArm.add(mesh(cylGeo, skin, 0.09, 0.26, 0.09, 0, -0.38, 0));
  leftArm.add(mesh(sphereGeo, skin, 0.1, 0.1, 0.1, 0, -0.54, 0));
  root.add(leftArm);

  const rightArm = new THREE.Group();
  rightArm.position.set(0.4, 1.34, 0);
  rightArm.add(mesh(cylGeo, dress, 0.1, 0.34, 0.1, 0, -0.1, 0));
  rightArm.add(mesh(cylGeo, skin, 0.09, 0.26, 0.09, 0, -0.38, 0));
  rightArm.add(mesh(sphereGeo, skin, 0.1, 0.1, 0.1, 0, -0.54, 0));
  root.add(rightArm);

  const head = new THREE.Group();
  head.position.set(0, 1.62, 0);
  head.add(mesh(sphereGeo, skin, 0.34, 0.33, 0.32, 0, 0.3, 0.05));
  head.add(mesh(sphereGeo, blush, 0.09, 0.07, 0.07, -0.2, 0.22, 0.22, false));
  head.add(mesh(sphereGeo, blush, 0.09, 0.07, 0.07, 0.2, 0.22, 0.22, false));
  head.add(mesh(sphereGeo, skin, 0.055, 0.045, 0.05, 0, 0.24, 0.32, false));

  head.add(mesh(sphereGeo, hair, 0.36, 0.18, 0.32, 0, 0.52, -0.02));
  head.add(mesh(sphereGeo, hair, 0.3, 0.22, 0.16, 0, 0.42, -0.22));
  head.add(mesh(sphereGeo, hair, 0.2, 0.1, 0.12, -0.22, 0.48, 0.12));
  head.add(mesh(sphereGeo, hair, 0.2, 0.1, 0.12, 0.22, 0.48, 0.12));
  head.add(mesh(boxGeo, hair, 0.42, 0.07, 0.12, 0, 0.54, 0.18));
  head.add(mesh(boxGeo, hair, 0.12, 0.09, 0.1, -0.16, 0.5, 0.22));
  head.add(mesh(boxGeo, hair, 0.12, 0.09, 0.1, 0.16, 0.5, 0.22));
  head.add(mesh(boxGeo, hair, 0.13, 0.06, 0.09, 0, 0.51, 0.23));

  const makeBraid = (side: number) => {
    const g = new THREE.Group();
    g.position.set(side * 0.3, 0.42, -0.12);
    g.rotation.z = side * 0.16;
    g.add(mesh(sphereGeo, dress, 0.08, 0.05, 0.08, 0, 0.04, 0.02, false));
    g.add(mesh(sphereGeo, dress, 0.05, 0.05, 0.05, side * 0.08, 0.04, 0.02, false));
    g.add(mesh(sphereGeo, dress, 0.05, 0.05, 0.05, -side * 0.08, 0.04, 0.02, false));
    const sizes = [0.1, 0.095, 0.09, 0.082, 0.072, 0.058];
    sizes.forEach((s, i) => {
      g.add(
        mesh(
          sphereGeo,
          hair,
          s,
          s * 1.08,
          s,
          0,
          -0.12 - i * 0.155,
          i % 2 === 0 ? 0.02 : -0.02,
        ),
      );
    });
    return g;
  };
  const braidL = makeBraid(-1);
  const braidR = makeBraid(1);
  head.add(braidL, braidR);

  const eyeL = new THREE.Group();
  eyeL.position.set(-0.11, 0.32, 0.3);
  eyeL.add(mesh(sphereGeo, white, 0.075, 0.08, 0.038, 0, 0, 0, false));
  eyeL.add(mesh(sphereGeo, eye, 0.048, 0.05, 0.032, 0, -0.004, 0.02, false));
  eyeL.add(mesh(sphereGeo, "#1a1008", 0.022, 0.022, 0.016, 0, -0.004, 0.038, false));
  eyeL.add(mesh(sphereGeo, "#fff", 0.014, 0.014, 0.01, 0.016, 0.016, 0.04, false));
  head.add(eyeL);

  const eyeR = new THREE.Group();
  eyeR.position.set(0.11, 0.32, 0.3);
  eyeR.add(mesh(sphereGeo, white, 0.075, 0.08, 0.038, 0, 0, 0, false));
  eyeR.add(mesh(sphereGeo, eye, 0.048, 0.05, 0.032, 0, -0.004, 0.02, false));
  eyeR.add(mesh(sphereGeo, "#1a1008", 0.022, 0.022, 0.016, 0, -0.004, 0.038, false));
  eyeR.add(mesh(sphereGeo, "#fff", 0.014, 0.014, 0.01, 0.016, 0.016, 0.04, false));
  head.add(eyeR);

  head.add(mesh(sphereGeo, "#c45a5a", 0.07, 0.025, 0.02, 0, 0.17, 0.33, false));
  root.add(head);

  root.userData.leftLeg = leftLeg;
  root.userData.rightLeg = rightLeg;
  root.userData.leftArm = leftArm;
  root.userData.rightArm = rightArm;
  root.userData.eyeL = eyeL;
  root.userData.eyeR = eyeR;
  root.userData.head = head;
  root.userData.braidL = braidL;
  root.userData.braidR = braidR;
  return root;
}

export function animateGirl(
  root: THREE.Group,
  moving: boolean,
  onGround: boolean,
  t: number,
  dt: number,
) {
  const speed = moving ? 11 : 0;
  root.userData.walkT = (root.userData.walkT ?? 0) + dt * speed;
  const swing = moving ? Math.sin(root.userData.walkT) * 0.55 : 0;
  (root.userData.leftLeg as THREE.Group).rotation.x = swing;
  (root.userData.rightLeg as THREE.Group).rotation.x = -swing;
  (root.userData.leftArm as THREE.Group).rotation.x = -swing * 0.7;
  (root.userData.rightArm as THREE.Group).rotation.x = swing * 0.7;
  const bob = moving ? Math.abs(Math.sin(root.userData.walkT)) * 0.04 : Math.sin(t * 2) * 0.015;
  (root.userData.head as THREE.Group).position.y = 1.62 + bob;
  if (!onGround) {
    (root.userData.leftLeg as THREE.Group).rotation.x = 0.35;
    (root.userData.rightLeg as THREE.Group).rotation.x = -0.15;
  }
  const blink = Math.sin(t * 0.9 + 1.7);
  const squish = blink > 0.97 ? 0.12 : 1;
  (root.userData.eyeL as THREE.Group).scale.y = squish;
  (root.userData.eyeR as THREE.Group).scale.y = squish;
  const braid = Math.sin(t * 2.4) * (moving ? 0.1 : 0.035);
  (root.userData.braidL as THREE.Group).rotation.z = -0.2 + braid;
  (root.userData.braidR as THREE.Group).rotation.z = 0.2 - braid;
}

export function makeDumpling(color: string, accent: string) {
  const g = new THREE.Group();
  const body = new THREE.Mesh(sphereGeo, lam(color, { roughness: 0.42 }));
  body.scale.set(0.55, 0.42, 0.55);
  body.castShadow = true;
  const top = new THREE.Mesh(sphereGeo, lam(accent, { roughness: 0.4 }));
  top.scale.set(0.26, 0.16, 0.26);
  top.position.y = 0.3;
  top.castShadow = true;
  const pinch = new THREE.Mesh(sphereGeo, lam(accent, { roughness: 0.4 }));
  pinch.scale.set(0.12, 0.1, 0.12);
  pinch.position.y = 0.42;
  const fold1 = new THREE.Mesh(sphereGeo, lam(color, { roughness: 0.45 }));
  fold1.scale.set(0.18, 0.1, 0.22);
  fold1.position.set(0.28, 0.08, 0.1);
  const fold2 = fold1.clone();
  fold2.position.set(-0.26, 0.1, -0.08);
  const fold3 = fold1.clone();
  fold3.scale.set(0.14, 0.08, 0.16);
  fold3.position.set(0.04, 0.06, -0.3);
  const shine = new THREE.Mesh(sphereGeo, lam("#fff6ee", { roughness: 0.2, opacity: 0.55, transparent: true }));
  shine.scale.set(0.14, 0.1, 0.08);
  shine.position.set(0.16, 0.18, 0.38);
  shine.castShadow = false;
  const leaf = new THREE.Mesh(coneGeo, lam("#5a9a4a", { roughness: 0.7 }));
  leaf.scale.set(0.08, 0.16, 0.05);
  leaf.position.set(0.08, 0.5, 0);
  leaf.rotation.z = 0.5;
  g.add(body, top, pinch, fold1, fold2, fold3, shine, leaf);
  g.userData.body = body;
  g.scale.setScalar(1.28);
  return g;
}

export function makeTree(variant = 0, scale = 1) {
  const g = new THREE.Group();
  const trunkC = variant === 1 ? "#7a4a2a" : "#5c3a22";
  const leafC = variant === 2 ? "#3f8a48" : variant === 1 ? "#6bb85a" : "#4e9a46";
  const leafDark = variant === 2 ? "#2f6e38" : variant === 1 ? "#4e9448" : "#3d7a38";
  const trunk = mesh(cylGeo, trunkC, 0.22, 2.2, 0.22, 0, 1.1, 0);
  g.add(trunk);
  g.add(mesh(cylGeo, trunkC, 0.12, 0.8, 0.12, 0.22, 1.7, 0.08));
  if (variant === 2) {
    g.add(mesh(coneGeo, leafDark, 1.55, 2.2, 1.55, 0, 2.9, 0));
    g.add(mesh(coneGeo, leafC, 1.4, 2.0, 1.4, 0, 3.15, 0));
    g.add(mesh(coneGeo, leafC, 1.1, 1.4, 1.1, 0, 3.9, 0));
    g.add(mesh(coneGeo, "#7ec85a", 0.75, 1.0, 0.75, 0, 4.5, 0));
  } else {
    g.add(mesh(sphereGeo, leafDark, 1.05, 0.9, 1.05, 0, 2.85, 0));
    g.add(mesh(sphereGeo, leafC, 1.05, 0.95, 1.05, 0, 3.05, 0));
    g.add(mesh(sphereGeo, leafC, 0.78, 0.7, 0.78, 0.48, 3.15, 0.18));
    g.add(mesh(sphereGeo, leafC, 0.7, 0.62, 0.7, -0.44, 3.2, -0.2));
    g.add(mesh(sphereGeo, "#7ec85a", 0.5, 0.42, 0.5, 0.12, 3.55, 0.32));
    if (variant === 1) {
      g.add(mesh(sphereGeo, "#d45a4a", 0.12, 0.12, 0.12, 0.55, 2.85, 0.4, false));
      g.add(mesh(sphereGeo, "#d45a4a", 0.1, 0.1, 0.1, -0.35, 3.05, 0.5, false));
    }
  }
  g.scale.setScalar(scale);
  return g;
}

export function makeHouse(body: string, roof: string, w = 6, d = 5) {
  const g = new THREE.Group();
  g.add(mesh(boxGeo, body, w, 4.2, d, 0, 2.1, 0));
  g.add(mesh(boxGeo, "#fff6ee", w + 0.12, 0.16, d + 0.12, 0, 3.95, 0, false));
  const roofM = new THREE.Mesh(cone4Geo, lam(roof, { roughness: 0.7 }));
  roofM.scale.set(w * 0.78, 2.4, d * 0.78);
  roofM.position.y = 5.2;
  roofM.rotation.y = Math.PI / 4;
  roofM.castShadow = true;
  g.add(roofM);
  g.add(mesh(boxGeo, "#8a5040", 0.7, 1.2, 0.7, w * 0.28, 5.7, -d * 0.12));
  g.add(mesh(boxGeo, "#5a3a28", 1.1, 2, 0.12, 0, 1.05, d * 0.5 + 0.02, false));
  g.add(mesh(boxGeo, "#c4a070", 1.18, 0.12, 0.14, 0, 2.08, d * 0.5 + 0.04, false));
  g.add(mesh(boxGeo, "#f2e28a", 0.9, 0.9, 0.08, -w * 0.22, 2.6, d * 0.5 + 0.02, false));
  g.add(mesh(boxGeo, "#f2e28a", 0.9, 0.9, 0.08, w * 0.22, 2.6, d * 0.5 + 0.02, false));
  g.add(mesh(boxGeo, "#d8c49a", 1.05, 0.12, 0.1, -w * 0.22, 3.1, d * 0.5 + 0.03, false));
  g.add(mesh(boxGeo, "#d8c49a", 1.05, 0.12, 0.1, w * 0.22, 3.1, d * 0.5 + 0.03, false));
  g.add(mesh(boxGeo, "#c4b48a", w + 0.8, 0.18, 1.4, 0, 0.1, d * 0.5 + 0.4, false));
  g.add(mesh(boxGeo, "#b8a078", w + 0.5, 0.12, 0.2, 0, 0.22, d * 0.5 + 1.0, false));
  return g;
}

export function makeCloud(scale = 1) {
  const g = new THREE.Group();
  const c = lam("#f7fbff", { roughness: 0.92, opacity: 0.94, transparent: true });
  const add = (x: number, y: number, z: number, s: number) => {
    const m = new THREE.Mesh(sphereGeo, c);
    m.scale.set(s, s * 0.72, s * 0.9);
    m.position.set(x, y, z);
    m.castShadow = false;
    g.add(m);
  };
  add(0, 0, 0, 1.5);
  add(1.4, 0.12, 0.2, 1.15);
  add(-1.3, 0.08, -0.18, 1.05);
  add(0.25, 0.55, -0.35, 0.95);
  add(-0.5, 0.35, 0.45, 0.8);
  add(0.9, 0.28, -0.7, 0.7);
  g.scale.setScalar(scale);
  g.userData.cloudDrift = true;
  return g;
}

export function makeLollipop(candy: string) {
  const g = new THREE.Group();
  g.add(mesh(cylGeo, "#f0e8dc", 0.08, 2.4, 0.08, 0, 1.2, 0, false));
  g.add(mesh(sphereGeo, candy, 0.7, 0.7, 0.22, 0, 2.5, 0));
  g.add(mesh(sphereGeo, "#fff6ee", 0.28, 0.28, 0.08, 0.18, 2.62, 0.16, false));
  return g;
}

export function makeFountain() {
  const g = new THREE.Group();
  g.add(mesh(cylGeo, "#d9d2c6", 2.4, 0.5, 2.4, 0, 0.25, 0));
  g.add(mesh(cylGeo, "#6cb4d4", 1.8, 0.28, 1.8, 0, 0.5, 0, false));
  g.add(mesh(cylGeo, "#d9d2c6", 0.28, 1.6, 0.28, 0, 1.1, 0));
  g.add(mesh(sphereGeo, "#9fd4ea", 0.45, 0.45, 0.45, 0, 2.05, 0, false));
  return g;
}

export function makeGazebo() {
  const g = new THREE.Group();
  const posts = [
    [-1.6, -1.6],
    [1.6, -1.6],
    [-1.6, 1.6],
    [1.6, 1.6],
  ];
  for (const [x, z] of posts) {
    g.add(mesh(cylGeo, "#e8d7b8", 0.12, 2.6, 0.12, x, 1.3, z));
    g.add(mesh(cylGeo, "#d4c09a", 0.16, 0.12, 0.16, x, 2.62, z, false));
  }
  g.add(mesh(cone4Geo, "#d45a4a", 2.6, 1.3, 2.6, 0, 3.1, 0));
  g.add(mesh(cone4Geo, "#c44a42", 1.4, 0.55, 1.4, 0, 3.7, 0));
  g.add(mesh(cylGeo, "#efe4d0", 2.1, 0.12, 2.1, 0, 0.06, 0, false));
  g.add(mesh(cylGeo, "#e2d2b4", 2.2, 0.08, 2.2, 0, 2.62, 0, false));
  return g;
}

export function makeSlide() {
  const g = new THREE.Group();
  g.add(mesh(boxGeo, "#f0c44a", 2.2, 2.6, 2.2, 0, 1.3, 0));
  g.add(mesh(boxGeo, "#e8b83a", 2.3, 0.12, 2.3, 0, 2.64, 0, false));
  const ramp = mesh(boxGeo, "#4f93c4", 1.4, 0.18, 4.2, 0, 1.2, 2.4);
  ramp.rotation.x = -0.55;
  g.add(ramp);
  g.add(mesh(boxGeo, "#d45a4a", 0.16, 0.7, 3.6, -0.7, 1.45, 2.2));
  g.add(mesh(boxGeo, "#d45a4a", 0.16, 0.7, 3.6, 0.7, 1.45, 2.2));
  g.add(mesh(boxGeo, "#e8d7b8", 0.4, 2.4, 0.4, -0.7, 2.4, -0.7));
  g.add(mesh(boxGeo, "#e8d7b8", 0.4, 0.18, 0.18, -0.7, 3.5, -0.2));
  g.add(mesh(boxGeo, "#e8d7b8", 0.4, 0.18, 0.18, -0.7, 3.2, 0.15));
  g.add(mesh(cylGeo, "#f0c44a", 0.22, 0.16, 0.22, 0.7, 2.72, 0.7, false));
  return g;
}

export function grassTexture() {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const g = c.getContext("2d")!;
  g.fillStyle = "#4fa056";
  g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 2200; i++) {
    const shade = Math.random();
    g.fillStyle = shade > 0.66 ? "#6fbf62" : shade > 0.33 ? "#4e9a4e" : "#3f8a44";
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    g.fillRect(x, y, 1 + Math.random() * 2, 3 + Math.random() * 5);
  }
  for (let i = 0; i < 40; i++) {
    g.fillStyle = Math.random() > 0.5 ? "#e8c46a" : "#d45a4a";
    g.beginPath();
    g.arc(Math.random() * 256, Math.random() * 256, 1.2, 0, Math.PI * 2);
    g.fill();
  }
  for (let y = 18; y < 256; y += 32) {
    for (let x = 18; x < 256; x += 32) {
      g.fillStyle = "rgba(255,255,255,0.16)";
      g.beginPath();
      g.arc(x, y, 5, 0, Math.PI * 2);
      g.fill();
      g.strokeStyle = "rgba(255,255,255,0.1)";
      g.lineWidth = 1;
      g.beginPath();
      g.arc(x, y, 7, 0, Math.PI * 2);
      g.stroke();
    }
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = THREE.RepeatWrapping;
  t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.repeat.set(56, 56);
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

export function pathTexture() {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 128;
  const g = c.getContext("2d")!;
  g.fillStyle = "#d4c094";
  g.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 220; i++) {
    g.fillStyle = Math.random() > 0.5 ? "#c4b086" : "#e4d4b0";
    g.beginPath();
    g.ellipse(Math.random() * 128, Math.random() * 128, 2 + Math.random() * 4, 1.5 + Math.random() * 3, Math.random(), 0, Math.PI * 2);
    g.fill();
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.repeat.set(6, 28);
  t.anisotropy = 4;
  t.needsUpdate = true;
  return t;
}

export function makeSky() {
  const geo = new THREE.SphereGeometry(220, 32, 20);
  const mat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms: {
      uTop: { value: new THREE.Color("#6eb6e8") },
      uMid: { value: new THREE.Color("#b7dcfa") },
      uHorizon: { value: new THREE.Color("#f3e2c4") },
    },
    vertexShader: `
      varying vec3 vDir;
      void main() {
        vDir = normalize(position);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      varying vec3 vDir;
      uniform vec3 uTop;
      uniform vec3 uMid;
      uniform vec3 uHorizon;
      void main() {
        float h = clamp(vDir.y * 0.5 + 0.5, 0.0, 1.0);
        vec3 col = mix(uHorizon, uMid, smoothstep(0.38, 0.55, h));
        col = mix(col, uTop, smoothstep(0.58, 0.92, h));
        float sun = pow(max(0.0, dot(normalize(vDir), normalize(vec3(0.35, 0.62, -0.4)))), 48.0);
        col += vec3(1.0, 0.92, 0.7) * sun * 0.55;
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.renderOrder = -10;
  mesh.frustumCulled = false;
  return mesh;
}

export function makeWaterMaterial(hex: string) {
  const deep = new THREE.Color(hex).lerp(new THREE.Color("#7eb8d8"), 0.35);
  const shallow = new THREE.Color("#dff4ff");
  return new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    uniforms: {
      uTime: { value: 0 },
      uDeep: { value: deep },
      uShallow: { value: shallow },
    },
    vertexShader: `
      varying vec3 vWorld;
      void main() {
        vec4 w = modelMatrix * vec4(position, 1.0);
        vWorld = w.xyz;
        gl_Position = projectionMatrix * viewMatrix * w;
      }
    `,
    fragmentShader: `
      varying vec3 vWorld;
      uniform float uTime;
      uniform vec3 uDeep;
      uniform vec3 uShallow;
      void main() {
        float w = sin(vWorld.x * 0.55 + uTime * 1.3) * 0.5 + cos(vWorld.z * 0.48 + uTime * 1.05) * 0.5;
        vec3 col = mix(uDeep, uShallow, 0.45 + 0.45 * w);
        float spark = pow(max(0.0, sin(vWorld.x * 2.4 + uTime * 2.8) * sin(vWorld.z * 2.1 + 0.7)), 10.0);
        col += vec3(0.75, 0.88, 0.92) * spark;
        gl_FragColor = vec4(col, 0.72);
      }
    `,
  });
}

export { boxGeo, sphereGeo, cylGeo, coneGeo, cone4Geo };
