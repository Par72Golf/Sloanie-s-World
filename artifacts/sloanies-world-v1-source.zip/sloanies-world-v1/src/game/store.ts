import { create } from "zustand";
import {
  DRESS,
  HAIR,
  type DressId,
  type HairId,
  type Phase,
  type QuizQ,
  type TempBand,
} from "./types";
import { loadSave, persistSave } from "./save";

const saved = loadSave();

export type GameStore = {
  phase: Phase;
  playerName: string;
  dress: DressId;
  hair: HairId;
  levelIndex: number;
  unlocked: number;
  collected: string[][];
  quiz: { dumplingId: string; q: QuizQ; attempts: number } | null;
  temp: TempBand;
  nearestName: string | null;
  nearestDist: number;
  nearCollect: boolean;
  hintText: string | null;
  hintsLeft: number;
  highlightedId: string | null;
  muted: boolean;
  journalOpen: boolean;
  interactGen: number;
  hintGen: number;
  fleeGen: number;
  fleeId: string | null;
  fleeNotice: string | null;
  setName: (v: string) => void;
  setDress: (v: DressId) => void;
  setHair: (v: HairId) => void;
  startLevel: (index?: number) => void;
  resumePlay: () => void;
  pause: () => void;
  openQuiz: (dumplingId: string, q: QuizQ) => void;
  bumpAttempt: () => void;
  closeQuiz: () => void;
  markCollected: (dumplingId: string) => void;
  completeLevel: () => void;
  nextLevel: () => void;
  replayLevel: () => void;
  toTitle: () => void;
  setHud: (p: {
    temp: TempBand;
    nearestName: string | null;
    nearestDist: number;
    nearCollect: boolean;
  }) => void;
  setHint: (text: string | null, dumplingId: string | null) => void;
  useHint: () => void;
  requestInteract: () => void;
  fleeDumpling: (id: string) => void;
  clearFleeNotice: () => void;
  clearHint: () => void;
  toggleMute: () => void;
  toggleJournal: () => void;
  setJournal: (v: boolean) => void;
};

function persistSlice(s: GameStore) {
  persistSave({
    version: 1,
    playerName: s.playerName,
    dress: s.dress,
    hair: s.hair,
    unlocked: s.unlocked,
    collected: s.collected,
    muted: s.muted,
    levelIndex: s.levelIndex,
  });
}

export const useGame = create<GameStore>((set, get) => ({
  phase: "title",
  playerName: saved.playerName,
  dress: saved.dress,
  hair: saved.hair,
  levelIndex: 0,
  unlocked: saved.unlocked,
  collected: saved.collected,
  quiz: null,
  temp: "cold",
  nearestName: null,
  nearestDist: 99,
  nearCollect: false,
  hintText: null,
  hintsLeft: 4,
  highlightedId: null,
  muted: saved.muted,
  journalOpen: false,
  interactGen: 0,
  hintGen: 0,
  fleeGen: 0,
  fleeId: null,
  fleeNotice: null,
  setName: (playerName) => {
    set({ playerName });
    persistSlice(get());
  },
  setDress: (dress) => {
    set({ dress });
    persistSlice(get());
  },
  setHair: (hair) => {
    set({ hair });
    persistSlice(get());
  },
  startLevel: (index) => {
    const levelIndex = index ?? get().levelIndex;
    set({
      phase: "playing",
      levelIndex,
      quiz: null,
      journalOpen: false,
      hintText: null,
      highlightedId: null,
      hintsLeft: 4,
      nearCollect: false,
      fleeNotice: null,
      fleeId: null,
    });
  },
  resumePlay: () => set({ phase: "playing" }),
  pause: () => {
    if (get().phase === "playing") set({ phase: "paused" });
  },
  openQuiz: (dumplingId, q) =>
    set({ phase: "quiz", quiz: { dumplingId, q, attempts: 0 } }),
  bumpAttempt: () => {
    const quiz = get().quiz;
    if (!quiz) return;
    set({ quiz: { ...quiz, attempts: quiz.attempts + 1 } });
  },
  closeQuiz: () => set({ phase: "playing", quiz: null }),
  fleeDumpling: (id) =>
    set((s) => ({
      phase: "playing",
      quiz: null,
      nearCollect: false,
      fleeId: id,
      fleeGen: s.fleeGen + 1,
      fleeNotice: "Oh no — it ran off! Hunt it down again.",
      hintText: null,
      highlightedId: null,
    })),
  clearFleeNotice: () => set({ fleeNotice: null }),
  clearHint: () => set({ hintText: null, highlightedId: null }),
  markCollected: (dumplingId) => {
    const { levelIndex, collected } = get();
    const next = collected.map((row, i) =>
      i === levelIndex
        ? Array.from(new Set([...row, dumplingId]))
        : row.slice(),
    );
    set({ collected: next, quiz: null, phase: "playing", nearCollect: false });
    persistSlice(get());
  },
  completeLevel: () => {
    const { levelIndex, unlocked } = get();
    const nextUnlock = Math.max(unlocked, levelIndex + 1);
    const last = levelIndex >= 2;
    set({
      phase: last ? "victory" : "complete",
      unlocked: nextUnlock,
      quiz: null,
    });
    persistSlice(get());
  },
  nextLevel: () => {
    const levelIndex = Math.min(2, get().levelIndex + 1);
    set({
      phase: "playing",
      levelIndex,
      quiz: null,
      hintsLeft: 4,
      hintText: null,
      highlightedId: null,
      journalOpen: false,
      fleeNotice: null,
      fleeId: null,
    });
  },
  replayLevel: () => {
    const { levelIndex, collected } = get();
    const next = collected.map((row, i) => (i === levelIndex ? [] : row.slice()));
    set({
      collected: next,
      phase: "playing",
      quiz: null,
      hintsLeft: 4,
      hintText: null,
      highlightedId: null,
      journalOpen: false,
      fleeNotice: null,
      fleeId: null,
    });
    persistSlice(get());
  },
  toTitle: () =>
    set({
      phase: "title",
      quiz: null,
      journalOpen: false,
      hintText: null,
      highlightedId: null,
      fleeNotice: null,
      fleeId: null,
    }),
  setHud: ({ temp, nearestName, nearestDist, nearCollect }) =>
    set({ temp, nearestName, nearestDist, nearCollect }),
  setHint: (hintText, highlightedId) => set({ hintText, highlightedId }),
  useHint: () => {
    if (get().hintsLeft <= 0 || get().phase !== "playing") return;
    set((s) => ({ hintsLeft: s.hintsLeft - 1, hintGen: s.hintGen + 1 }));
  },
  requestInteract: () => set({ interactGen: get().interactGen + 1 }),
  toggleMute: () => {
    set({ muted: !get().muted });
    persistSlice(get());
  },
  toggleJournal: () => set({ journalOpen: !get().journalOpen }),
  setJournal: (journalOpen) => set({ journalOpen }),
}));

export function dressHex() {
  return DRESS[useGame.getState().dress];
}
export function hairHex() {
  return HAIR[useGame.getState().hair];
}
